<?php
// Add a custom endpoint for handling Google Calendar code
add_action('init', 'register_google_calendar_endpoint');
function register_google_calendar_endpoint()
{
    add_rewrite_endpoint('google-calendar-sync', EP_ROOT);
}


// Hook into the custom endpoint to handle Google Calendar code
add_action('template_redirect', 'handle_google_calendar_code');
function handle_google_calendar_code() {

    if (get_query_var('google-calendar-sync')) {
        $code = isset($_GET['code']) ? $_GET['code'] : '';

        //include API config file
        require_once 'config.php';

        // Initialize Google Calendar API class 
        include_once 'GoogleCalendarApi.class.php';

        if (isset($_GET['code'])) {
            // Initialize Google Calendar API class 
            $GoogleCalendarApi = new GoogleCalendarApi();

            // Get event ID from session 
            $event_id = isset($_SESSION['last_event_id']) ? $_SESSION['last_event_id'] : '';

            if (!empty($event_id)) {
                global $wpdb;
                $table_name_events = $wpdb->prefix . 'gcms_appointments';

                // Fetch event details from database
                $eventData = $wpdb->get_row(
                    $wpdb->prepare("SELECT * FROM $table_name_events WHERE id = %d", $event_id),
                    ARRAY_A
                );

                if (!empty($eventData)) {
                    $calendar_event = array(
                        'summary' => 'Meeting with' . $eventData['first_name'] . $eventData['last_name'],
                        'location' => 'Google Meet',
                        'description' => 'Online Video Conference meeting',
                        'conferenceData' => array(
                            'createRequest' => array(
                                'requestId' => uniqid(),
                            ),
                        ),
                    );

                    $end_time = date('H:i:s', strtotime($eventData['preferred_time']) + 15 * 60);

                    $event_datetime = array(
                        'event_date' => $eventData['preferred_date'],
                        'start_time' => $eventData['preferred_time'],
                        'end_time' => $end_time
                    );
                }
            }
        }

        // Get access token from session or wherever you're storing it ----2
        $access_token_sess = isset($_SESSION['google_access_token']) ? $_SESSION['google_access_token'] : null;

        if (!empty($access_token_sess)) {
            $access_token = $access_token_sess;
        } else {
            $data = $GoogleCalendarApi->GetAccessToken(GOOGLE_CLIENT_ID, REDIRECT_URI, GOOGLE_CLIENT_SECRET, $_GET['code']);
            $access_token = $data['access_token'];
            $_SESSION['google_access_token'] = $access_token;
        }

        if (!empty($access_token)) {
            try {
                // Get the user's calendar timezone 
                $user_timezone = $GoogleCalendarApi->GetUserCalendarTimezone($access_token);

                // Create an event on the primary calendar 
                $google_event_id = $GoogleCalendarApi->CreateCalendarEvent($access_token, 'primary', $calendar_event, 0, $event_datetime, $user_timezone);

                if ($google_event_id) {
                    // Update the database with Google Calendar event ID

                    // Generate Google Meet link for the created event
                    $meetLink = $GoogleCalendarApi->GenerateMeetLink($google_event_id, $access_token);

                    global $wpdb;
                    $table_name_events = $wpdb->prefix . 'gcms_appointments';

                    $update_data = array(
                        'event_id' => $google_event_id,
                        'meet_link' => $meetLink
                    );

                    $where_clause = array(
                        'id' => $event_id
                    );

                    $update_result = $wpdb->update($table_name_events, $update_data, $where_clause);

                    if ($update_result !== false) {
                        // Update successful
                        unset($_SESSION['last_event_id']);
                        unset($_SESSION['google_access_token']);

                        // Store data in session variables
                        $_SESSION['event_id'] = $event_id;
                        $_SESSION['meet_link'] = $meetLink;

                        // Redirect to the success page
                        //  wp_redirect(get_permalink(YOUR_SUCCESS_PAGE_ID));

                        // Display success message in a modal popup
                        echo '<script>alert("Appointment booked successfully!!!");</script>';

                        // Redirect or display a success message
                        wp_redirect(get_permalink(SUCCESS_PAGE_ID));


                        exit();
                    } else {
                        echo '<script>alert("DB UPDATE FAILED!!!");</script>';

                    }
                }
            }

        }

    }
}