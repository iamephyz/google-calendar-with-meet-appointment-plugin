<?php

// Google API configuration  -- ANOTHER CODE SNIPPET --
define('GOOGLE_CLIENT_ID', '726226002797-tr25b1rvnkc31n7l0i40khvmbvac39fp.apps.googleusercontent.com'); //Google_Project_Client_ID
define('GOOGLE_CLIENT_SECRET', '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'); //Google_Project_Client_Secret
define('GOOGLE_OAUTH_SCOPE', 'https://www.googleapis.com/auth/calendar');
define('REDIRECT_URI', plugin_dir_url(__FILE__) . 'GoogleCalendarSyncFunction.php');
//define('REDIRECT_URI','http://localhost/devephy/wp-content/plugins/Google-Calendar-Appointment/GoogleCalendarSyncFunction.php');


// Start session 
if(!session_id()) session_start(); 

// Google OAuth URL 
$googleOauthURL = 'https://accounts.google.com/o/oauth2/auth?scope=' . urlencode(GOOGLE_OAUTH_SCOPE) . '&redirect_uri=' . REDIRECT_URI . '&response_type=code&client_id=' . GOOGLE_CLIENT_ID . '&access_type=online';
