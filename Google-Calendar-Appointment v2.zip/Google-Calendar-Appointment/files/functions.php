<?php

// Shortcode to display the appointment form...
function google_calendar_appointment_form_shortcode()
{
    ob_start();
    ?>

    <div id="appointment-form" class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <h2 class="text-center mb-4">Schedule an Appointment</h2>
                <form id="appointmentForm" method="post">
                    <div class="form-group">
                        <label for="first_name">First Name</label>
                        <input type="text" class="form-control" id="first_name" name="first_name"
                            placeholder="Enter your first name" required>
                    </div>
                    <div class="form-group">
                        <label for="last_name">Last Name</label>
                        <input type="text" class="form-control" id="last_name" name="last_name"
                            placeholder="Enter your last name" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email"
                            required>
                    </div>
                    <div class="form-group">
                        <label for="preferred_date">Preferred Date</label>
                        <input type="date" class="form-control" id="preferred_date" name="preferred_date" required>
                    </div>
                    <div class="form-group">
                        <label for="preferred_time">Preferred Time</label>
                        <select class="form-control" id="preferred_time" name="preferred_time" required>
                            <option value="09:00:00">9:00 AM - 9:15 AM</option>
                            <option value="09:45:00">9:45 AM - 10:00 AM</option>
                            <option value="10:30:00">10:30 AM - 10:45 AM</option>
                            <option value="11:15:00">11:15 AM - 11:30 AM</option>
                            <option value="12:00:00">12:00 PM - 12:15 PM</option>
                            <option value="12:45:00">12:45 PM - 1:00 PM</option>
                            <option value="13:30:00">1:30 PM - 1:45 PM</option>
                            <option value="14:15:00">2:15 PM - 2:30 PM</option>
                            <option value="15:00:00">3:00 PM - 3:15 PM</option>
                            <option value="15:45:00">3:45 PM - 4:00 PM</option>
                            <option value="16:30:00">4:30 PM - 4:45 PM</option>
                            <option value="17:15:00">5:15 PM - 5:30 PM</option>
                            <option value="18:00:00">6:00 PM - 6:15 PM</option>
                            <option value="18:45:00">6:45 PM - 7:00 PM</option>
                            <!-- Add more options for different time slots -->
                        </select>
                    </div>

                    <!-- Add more form fields as needed -->
                    <button type="submit" class="btn btn-primary btn-block" name="submit_appointment">Submit</button>
                </form>
            </div>
        </div>
    </div>

    <?php
    return ob_get_clean();
}
add_shortcode('GCMS-form', 'google_calendar_appointment_form_shortcode');



// Sanitize and validate form data...
function sanitize_appointment_data($data)
{
    $sanitized_data = array();

    if (isset($data['first_name'])) {
        $sanitized_data['first_name'] = sanitize_text_field($data['first_name']);
    }

    if (isset($data['last_name'])) {
        $sanitized_data['last_name'] = sanitize_text_field($data['last_name']);
    }

    if (isset($data['email'])) {
        $sanitized_data['email'] = sanitize_email($data['email']);
    }

    if (isset($data['preferred_date'])) {
        $sanitized_data['preferred_date'] = sanitize_text_field($data['preferred_date']);
    }

    if (isset($data['preferred_time'])) {
        $sanitized_data['preferred_time'] = sanitize_text_field($data['preferred_time']);
    }

    return $sanitized_data;
}

// Function to handle form submission and Google Calendar integration...
function handle_appointment_submission()
{
    // When button is clicked
    if (isset($_POST['submit_appointment'])) {
        // Sanitize and validate form data...
        $sanitized_data = sanitize_appointment_data($_POST);

        if (empty($sanitized_data['first_name']) || empty($sanitized_data['last_name']) || empty($sanitized_data['email'])) {
            echo '<script>alert("Please fill in all required fields.");</script>';
            return;
        }

        // Store data in the WordPress database table...INITIAL INSERT
        global $wpdb;
        $table_name = $wpdb->prefix . 'gcms_appointments';
        $insert_result = $wpdb->insert($table_name, $sanitized_data);

        // DATA FROM PREV CODE
        if ($insert_result) {
            $event_id = $wpdb->insert_id; // Get the last inserted ID

            // Store event ID in session
            $_SESSION['last_event_id'] = $event_id;

            include_once 'config.php'; // to add the googleOauth variable
            header("Location: $googleOauthURL");
            exit();
        } else {
            echo '<script>alert("INSERTION FAILED!!!");</script>';
        }

        // Include the Google Calendar synchronization function
        include_once 'GoogleCalendarSyncFunction.php';


    }
}

add_action('init', 'handle_appointment_submission');