<?php

// Admin menu creation
function gcms_create_menu() {
    add_menu_page(
        'GCMS_appointments', // Page title
        'GCMS', // Menu title
        'manage_options', // Capability
        'gcms_entries', // Menu slug
        'gcms_display_entries', // Callback function to display entries page
        'dashicons-calendar', // Dashicon class
        20 // Menu position (adjust as needed)
    );
}
add_action('admin_menu', 'gcms_create_menu');

// Callback function to display entries page
function gcms_display_entries() {
    ?>
    <div class="text-center"> <!-- Add 'text-center' class to center the content -->
        <h1>Google Calendar & Meet Scheduler</h1> <!-- Remove 'text-center' class from heading -->
        <p>Welcome to the Google Calendar & Meet Scheduler plugin. Use the <code><strong>[GCMS-form]</strong> </code>shortcode to display the appointment form.</p> <br> <br>
        <h2 class="gcms-h2"></h2> All Appointments </h2>
        <?php
        // Display the list of entries
        global $wpdb;
        $table_name = $wpdb->prefix . 'gcms_appointments';
        $appointments = $wpdb->get_results("SELECT * FROM $table_name");

        if ($appointments) {
            echo '<table class="wp-list-table widefat fixed striped">';
            echo '<thead>
            <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Date</th>
            <th>Time</th>
            
            <th>Event ID </th>
            <th>Google Meet Link</th>
            </tr></thead>';
            echo '<tbody>';
            foreach ($appointments as $appointment) {
                echo '<tr>';
                echo '<td>' . $appointment->first_name . ' ' . $appointment->last_name . '</td>';
                echo '<td>' . $appointment->email . '</td>';
                echo '<td>' . $appointment->preferred_date . '</td>';
                echo '<td>' . $appointment->preferred_time . '</td>';
                echo '<td>' . $appointment->event_id . '</td>';
                echo '<td><a href="' . $appointment->meet_link . '">' . $appointment->meet_link . '</a></td>';
                echo '</tr>';
            }
            echo '</tbody></table>';
        } else {
            echo '<p>No appointments found.</p>';
        }
        ?>
    </div>
    <?php
}

