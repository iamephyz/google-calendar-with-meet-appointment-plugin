<?php
/*
Plugin Name: Google Calendar & Meet Scheduler
Description: A plugin to schedule appointments and sync with Google Calendar.
Version: 1.0
Author: Ephraim Edeh
Author URI: https://webephy.com
*/

// Function to Enqueue scripts and styles...
function google_calendar_appointment_enqueue_scripts()
{
  
    wp_enqueue_style('bootstrap', 'https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');

    // Enqueue custom style
    wp_enqueue_style('google-calendar-appointment-style', plugin_dir_url(__FILE__) . 'css/style.css');
}
add_action('wp_enqueue_scripts', 'google_calendar_appointment_enqueue_scripts');

// Function to create appointments table on plugin activation
function gcms_create_appointments_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'GCMS_appointments';

    // Check if the table exists
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            first_name varchar(255) NOT NULL,
            last_name varchar(255) NOT NULL,
            email varchar(255) NOT NULL,
            preferred_date date NOT NULL,
            preferred_time varchar(255) NOT NULL,
            event_id varchar(255), -- Store Google Calendar event ID
            meet_link varchar(255), -- Store Google Meet link
            PRIMARY KEY (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    } else {
        // Check if the table has data
        $row_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
        
        if ($row_count == 0) {
            // Table exists, but no data, recreate the structure
            $charset_collate = $wpdb->get_charset_collate();
            
            $sql = "CREATE TABLE $table_name (
                id mediumint(9) NOT NULL AUTO_INCREMENT,
                first_name varchar(255) NOT NULL,
                last_name varchar(255) NOT NULL,
                email varchar(255) NOT NULL,
                preferred_date date NOT NULL,
                preferred_time varchar(255) NOT NULL,
                event_id varchar(255), -- Store Google Calendar event ID
                meet_link varchar(255), -- Store Google Meet link
                PRIMARY KEY (id)
            ) $charset_collate;";
            
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
        }
        // If there is data, do nothing
    }
}

// Register hooks and files
// Include the functions file
require_once plugin_dir_path(__FILE__) . 'files/functions.php';
//Activate appointments table
register_activation_hook(__FILE__, 'gcms_create_appointments_table');

// Include the entries page
require_once plugin_dir_path(__FILE__) . 'files/gcms_entries_page.php';

